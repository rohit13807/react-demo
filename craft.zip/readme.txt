

1) Run "npm install" in the extracted folder
2) Run "npm start" to view the project
2) Run "npm run build" to create build
