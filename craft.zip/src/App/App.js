import React from 'react';
import { Router, Route } from 'react-router-dom';
import { connect } from 'react-redux';

import { history } from '../helpers';
import { alertActions } from '../actions';
import { PrivateRoute } from '../components';
import { HomePage } from '../HomePage';
import { LoginPage } from '../LoginPage';
import { RegisterPage } from '../RegisterPage';
import { DashboardPage } from '../Dashboard';
import { AdminPage } from '../Features';
import { User } from '../Features/Admin/User/index';
import { UserList } from '../Features/Admin/User/user-list';

import { Category } from '../Features/Admin/Category';
import { CategoryList } from '../Features/Admin/Category';

import { SubCategory } from '../Features/Admin/SubCategory';
import { SubCategoryList } from '../Features/Admin/SubCategory';

import { Product } from '../Features/Admin/Product';
import { ProductList } from '../Features/Admin/Product';

import { AboutPage } from '../About/';


class App extends React.Component {
    constructor(props) {
        super(props);

        const { dispatch } = this.props;
        history.listen((location, action) => {
            // clear alert on location change
            dispatch(alertActions.clear());
        });
    }

    render() {
        const { alert } = this.props;
        return (
            
            <Router history={history}>
                <div>
                    <Route exact path="/" component={HomePage} />
                    <Route path="/login" component={LoginPage} />
                    <Route path="/register" component={RegisterPage} />
                    <Route path="/about" component={AboutPage} />
                    <PrivateRoute path="/dashboard" component={DashboardPage} />
                    <PrivateRoute path="/admin-section" component={AdminPage} />
                    <PrivateRoute path="/user" component={User} />
                    <PrivateRoute path="/user-list" component={UserList} />
                    <PrivateRoute path="/category-add" component={Category} />
                    <PrivateRoute path="/category-list" component={CategoryList} />
                    <PrivateRoute path="/sub-category-add" component={SubCategory} />
                    <PrivateRoute path="/sub-category-list" component={SubCategoryList} />
                    <PrivateRoute path="/product-add" component={Product} />
                    <PrivateRoute path="/product-update/:id" component={Product} />
                    <PrivateRoute path="/product-list" component={ProductList} />
                    
                </div>
            </Router>
                    
        );
    }
}

function mapStateToProps(state) {
    // console.log('App state: ', state);
    const { alert } = state;
    return {
        alert
    };
}

const connectedApp = connect(mapStateToProps)(App);
export { connectedApp as App }; 