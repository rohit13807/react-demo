import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

import { HeaderPage } from '../Header';
import { FooterPage } from '../Footer';

class AboutPage extends React.Component {
    
    render() {
        // const { user, users } = this.props;
        return (
            <div>
                <HeaderPage />
                <div className="featured-image" style={{backgroundImage: 'url(/assets/img/featured-image/about.jpg)'}}></div>
                <section className="container padding-top-3x padding-bottom-3x">
                <h1>About</h1>
                <div className="row padding-top">
                    <div className="col-md-5 col-sm-6 padding-bottom">
                    <h3>The Brand</h3>
                    <p className=" space-top">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>
                    </div>
                    <div className="col-sm-6 col-md-offset-1 padding-bottom">
                    <h3>Mission</h3>
                    <div className="quotation padding-top">
                        <div className="quotation-author">
                        <div className="quotation-author-ava">
                            <img src="/assets/img/team/quote_author.jpg" alt="James Cameron" />
                        </div>
                        </div>
                        <blockquote>
                        <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem.</p>
                        <cite>C.J. Cameron, Founder M-store Ltd.</cite>
                        </blockquote>
                    </div>
                    </div>
                </div>
                <hr className="padding-bottom" />
                <h3>Our Team</h3>
                <div className="row padding-top">
                    <div className="col-xs-6 col-md-3">
                    <div className="teammate">
                        <div className="teammate-thumb">
                        <div className="social-bar text-center space-bottom">
                            <a href="#" className="sb-skype" data-toggle="tooltip" data-placement="top" title="Skype">
                            <i className="socicon-skype"></i>
                            </a>
                            <a href="#" className="sb-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                            <i className="socicon-facebook"></i>
                            </a>
                            <a href="#" className="sb-google-plus" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google+">
                            <i className="socicon-googleplus"></i>
                            </a>
                        </div>
                        <img src="/assets/img/team/01.jpg" alt="Teammate" />
                        </div>
                        <h4 className="teammate-name">Jonathan Doe</h4>
                        <span className="teammate-position">Co-Founder, CEO</span>
                    </div>
                    </div>
                    <div className="col-xs-6 col-md-3">
                    <div className="teammate">
                        <div className="teammate-thumb">
                        <div className="social-bar text-center space-bottom">
                            <a href="#" className="sb-twitter" data-toggle="tooltip" data-placement="top" title="Twitter">
                            <i className="socicon-twitter"></i>
                            </a>
                            <a href="#" className="sb-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                            <i className="socicon-facebook"></i>
                            </a>
                            <a href="#" className="sb-instagram" data-toggle="tooltip" data-placement="top" title="" data-original-title="Instagram">
                            <i className="socicon-instagram"></i>
                            </a>
                        </div>
                        <img src="/assets/img/team/02.jpg" alt="Teammate" />
                        </div>
                        <h4 className="teammate-name">Branda Murray</h4>
                        <span className="teammate-position">Marketing Director</span>
                    </div>
                    </div>
                    <div className="col-xs-6 col-md-3">
                    <div className="teammate">
                        <div className="teammate-thumb">
                        <div className="social-bar text-center space-bottom">
                            <a href="#" className="sb-twitter" data-toggle="tooltip" data-placement="top" title="Twitter">
                            <i className="socicon-twitter"></i>
                            </a>
                            <a href="#" className="sb-linkedin" data-toggle="tooltip" data-placement="top" title="LinkedIn">
                            <i className="socicon-linkedin"></i>
                            </a>
                            <a href="#" className="sb-dribbble" data-toggle="tooltip" data-placement="top" title="" data-original-title="Dribbble">
                            <i className="socicon-dribbble"></i>
                            </a>
                        </div>
                        <img src="/assets/img/team/03.jpg" alt="Teammate" />
                        </div>
                        <h4 className="teammate-name">Taylor White</h4>
                        <span className="teammate-position">Brand Director</span>
                    </div>
                    </div>
                    <div className="col-xs-6 col-md-3">
                    <div className="teammate">
                        <div className="teammate-thumb">
                        <div className="social-bar text-center space-bottom">
                            <a href="#" className="sb-skype" data-toggle="tooltip" data-placement="top" title="Skype">
                            <i className="socicon-skype"></i>
                            </a>
                            <a href="#" className="sb-facebook" data-toggle="tooltip" data-placement="top" title="Facebook">
                            <i className="socicon-facebook"></i>
                            </a>
                            <a href="#" className="sb-google-plus" data-toggle="tooltip" data-placement="top" title="" data-original-title="Google+">
                            <i className="socicon-googleplus"></i>
                            </a>
                        </div>
                        <img src="/assets/img/team/04.jpg" alt="Teammate" />
                        </div>
                        <h4 className="teammate-name">Suasanna Davis</h4>
                        <span className="teammate-position">Sales Director</span>
                    </div>
                    </div>
                </div>
                </section>
                <FooterPage />
            </div>
        )
    }
}

function mapStateToProps(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return {
        user,
        users
    };
}

const connectedAboutPage = connect(mapStateToProps)(AboutPage);
export { connectedAboutPage as AboutPage };