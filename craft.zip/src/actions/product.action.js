import swal from 'sweetalert';

// import { userConstants } from '../constants';
// import { userService } from '../services';
import { alertActions } from './';
import { history } from '../helpers';

import { productService } from '../services';

import { productConstant } from '../constants';

export const productActions = {
    addProduct,
    getAllProducts,
    deleteProduct,
    getSingleProduct
};

function addProduct(data) {
    return dispatch => {
        dispatch(request(data));

        productService.addProduct(data)
            .then(
                data => {
                    dispatch(success());
                    history.push('/product-list');
                    dispatch(alertActions.success('Product added successfully.'));

                    swal({
                        title: "Saved!",
                        text: "Product added successfully.",
                        icon: "success",
                        button: "OK",
                      });
                },
                error => {
                    swal({
                        title: "Cannot saved!",
                        text: error,
                        icon: "error",
                        button: "OK",
                      });
                    dispatch(failure(error.toString()));
                    dispatch(alertActions.error(error.toString()));
                }
            );
    };
    function request(data) { return { type: productConstant.ADD_PRODUCT_REQUEST, data } }
    function success(data) { return { type: productConstant.ADD_PRODUCT_SUCCESS, data } }
    function failure(error) { return { type: productConstant.ADD_PRODUCT_FAILURE, error } }
}

function getAllProducts() {
    return dispatch => {
        dispatch(request());
        console.log('Get all Product Action');
        productService.getAllProducts()
            .then(
                products => dispatch(success(products)),
                error => dispatch(failure(error.toString()))
            );
    };

    function request() { return { type: productConstant.GETALL_PRODUCTS_REQUEST } }
    function success(products) { return { type: productConstant.GETALL_PRODUCTS_SUCCESS, products } }
    function failure(error) { return { type: productConstant.GETALL_PRODUCTS_FAILURE, error } }
}

function deleteProduct(id) {
    return dispatch => {
        dispatch(request(id));

        productService.deleteProduct(id)
            .then(
                user => {
                    history.push('/product-list');
                    dispatch(success(id));
                    dispatch(alertActions.success('Product deleted successfully.'));
                },
                error => dispatch(failure(id, error.toString()))
            );
    };

    function request(id) { return { type: productConstant.PRODUCT_DELETE_REQUEST, id } }
    function success(id) { return { type: productConstant.PRODUCT_DELETE_SUCCESS, id } }
    function failure(id, error) {  return { type: productConstant.PRODUCT_DELETE_FAILURE, id, error } }
}


function getSingleProduct(id) {

    return dispatch => {
        dispatch(request(id));
        history.push(`/product-update/${id}`);
        productService.getProductById(id)
            .then(
                user => {
                    history.push(`/product-update/${id}`);
                    dispatch(success(id));
                    dispatch(alertActions.success('Fetch single product detail.'));
                },
                error => dispatch(failure(id, error.toString()))
            );
    };

    function request(id) { return { type: productConstant.GET_SINGLE_PRODUCT_REQUEST, id } }
    function success(id) { return { type: productConstant.GET_SINGLE_PRODUCT_SUCCESS, id } }
    function failure(id, error) { return { type: productConstant.GET_SINGLE_PRODUCT_FAILURE, id, error } }

}