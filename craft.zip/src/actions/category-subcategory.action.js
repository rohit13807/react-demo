import swal from 'sweetalert';

// import { userService } from '../services';
import { categorySubCategoryService } from '../services';

import { alertActions } from '.';
import { history } from '../helpers';
import { categorySubCategoryConstants } from '../constants';

export const categorySubCategoryActions = {
    addCategory,
    getAllCategory,
    deleteCategory,
    addSubCategory,
    deleteSubCategory
};

function addCategory(data) {
    return dispatch => {
        dispatch(request(data));

        categorySubCategoryService.addCategory(data)
            .then(
                data => { 
                    dispatch(success());
                    history.push('/category-list');
                    dispatch(alertActions.success('Category added successfully.'));

                    swal({
                        title: "Saved!",
                        text: "Category added successfully.",
                        icon: "success",
                        button: "OK",
                    });
                },
                error => {
                    dispatch(failure(error.toString()));
                    dispatch(alertActions.error(error.toString()));

                    swal({
                        title: "Cannot saved!",
                        text: {error},
                        icon: "danger",
                        button: "OK",
                    });
                }
            );
    };
    function request(data) { return { type: categorySubCategoryConstants.ADD_CATEGORY_REQUEST, data } }
    function success(data) { return { type: categorySubCategoryConstants.ADD_CATEGORY_SUCCESS, data } }
    function failure(error) { return { type: categorySubCategoryConstants.ADD_CATEGORY_FAILURE, error } }
}


// get all listing of category .....

function getAllCategory() {
    return dispatch => {
        dispatch(request());
        
        categorySubCategoryService.getAllCategory()
            .then(
                data =>  dispatch(success(data)),
                error => dispatch(failure(error.toString()))
            );
    };
    
    function request() { return { type: categorySubCategoryConstants.GETALL_CATEGORY_REQUEST } }
    function success(data) { return { type: categorySubCategoryConstants.GETALL_CATEGORY_SUCCESS, data } }
    function failure(error) { return { type: categorySubCategoryConstants.GETALL_CATEGORY_FAILURE, error } }
}

function deleteCategory(id) {
    return dispatch => {
        dispatch(request(id));

        categorySubCategoryService.deleteCategory(id)
            .then(
                user => {
                    history.push('/category-list');
                    dispatch(success(id));
                    dispatch(alertActions.success('Category deleted successfully.'));
                },
                error => dispatch(failure(id, error.toString()))
            );
    };

    function request(id) { return { type: categorySubCategoryConstants.CATEGORY_DELETE_REQUEST, id } }
    function success(id) { return { type: categorySubCategoryConstants.CATEGORY_DELETE_SUCCESS, id } }
    function failure(id, error) { return { type: categorySubCategoryConstants.CATEGORY_DELETE_FAILURE, id, error } }
}


function addSubCategory(data) {
    return dispatch => {
        dispatch(request(data));

        categorySubCategoryService.addSubCategory(data)
            .then(
                data => { 
                    dispatch(success());
                    history.push('/sub-category-list');
                    dispatch(alertActions.success('Sub-category added successfully.'));

                    swal({
                        title: "Saved!",
                        text: "Sub-category added successfully.",
                        icon: "success",
                        button: "OK",
                      });
                },
                error => {
                    swal({
                        title: "Cannot saved!",
                        text: error,
                        icon: "error",
                        button: "OK",
                      });

                    dispatch(failure(error.toString()));
                    dispatch(alertActions.error(error.toString()));
                }
            );
    };
    function request(data) { return { type: categorySubCategoryConstants.ADD_CATEGORY_REQUEST, data } }
    function success(data) { return { type: categorySubCategoryConstants.ADD_CATEGORY_SUCCESS, data } }
    function failure(error) { return { type: categorySubCategoryConstants.ADD_CATEGORY_FAILURE, error } }
}


function deleteSubCategory(catId, subcatId ) {
    return dispatch => {
        dispatch(request(catId, subcatId));

        categorySubCategoryService.deleteSubCategory(catId, subcatId)
            .then(
                user => {
                    history.push('/sub-category-list');
                    dispatch(success(catId, subcatId));
                    dispatch(alertActions.success('Sub-category deleted successfully.'));
                },
                error => dispatch(failure(catId, subcatId, error.toString()))
            );
    };

    function request(catId, subcatId) { return { type: categorySubCategoryConstants.SUB_CATEGORY_DELETE_REQUEST, catId, subcatId } }
    function success(catId, subcatId) { return { type: categorySubCategoryConstants.SUB_CATEGORY_DELETE_SUCCESS, catId, subcatId } }
    function failure(catId, subcatId, error) { return { type: categorySubCategoryConstants.SUB_CATEGORY_DELETE_FAILURE, catId, subcatId, error } }
}